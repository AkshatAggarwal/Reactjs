import React from 'react';
import ReactDOM from 'react-dom';
import fetch from 'isomorphic-fetch';
import IconButton from 'material-ui/IconButton';
import ActionHome from 'material-ui/svg-icons/action/home'


class AppResort extends React.Component{
constructor(){
super();
this.state={data:[]}
}
componentDidMount(){
fetch('http://localhost:3000/resortpending',
{
method:"GET",
headers:{
'Accept':'application/json',
'Content-Type':'application/json',
}
})
.then(response =>{return response.json();})
.then(response =>{this.setState({data:response})})

}
render(){
return(
	<div>
	<ResortLeft RData={this.state.data} />
	</div>
)
}
}
export default AppResort;

class ResortLeft extends React.Component{
constructor(){
super();
}

render(){
var Data=this.props.RData;
var Resorts=Data==undefined?null:Data.map(ResortData=> <div><AllData resdata={ResortData}/></div>)
return(
<div>
	{Resorts}
	
</div>
)
}
}
class AllData extends React.Component{
constructor(){
super();
}

Approve(e){
debugger;
fetch('http://localhost:3000/resortapprove',
{
method:"POST",
headers:{
'Accept':'application/json',
'Content-Type':'application/json',
},
body:JSON.stringify({
_id:e.target.value
})
})
.then(function(response){return response.json();})
.then(function(data){console.log(data);})
}


render(){
return(

	<div>{this.props.resdata.RName}	<br/>	{this.props.resdata.EMPID}
	<button value={this.props.resdata._id} onClick={this.Approve.bind(this)}>Approve{this.props.resdata._id}</button>
	</div>
)
}
}