import React from 'react';
import ReactDOM from 'react-dom';
import fetch from 'isomorphic-fetch';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import 'es6-promise';


class AddRestraurant extends React.Component{
constructor(){
super();
this.state={RName:''}
}
handle_rname(e){this.setState({RName:e.target.value})}

addrestraurants()
{
		fetch('http://localhost:3000/postresort',
		{
		method:"POST",
		headers:{
				'Accept':'application/json',
				'Content-Type':'application/json',

			},
		body:JSON.stringify({
			RName:this.state.RName,
			EMPID:"988977"
			})
		})
		.then(function(response){
			console.log(response.ok);
			console.log("Data Sent")
			
		})
		.then(function(response){
			console.log(response);
		})

}
render(){
return(
<div>
	<TextField hintText="Restraurant Name" floatingLabelText="Restraurant Name" onKeyUp={this.handle_rname.bind(this)} />
	<RaisedButton label="Submit" primary={true} type="submit" onClick={this.addrestraurants.bind(this)}/>
	
</div>
)
}
}

export default AddRestraurant;