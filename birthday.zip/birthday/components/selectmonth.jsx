import React from 'react';
import ReactDOM from 'react-dom';
import SelectField from 'material-ui/SelectField';
import AddNew from './addnewicon.jsx';
import MenuItem from 'material-ui/MenuItem';
import GetBirthdays from './getbirthdays.jsx';
import Users from './AdminUsers.jsx';
import {Link} from 'react-router';

const items = [];
var month;
const months=["Jan","Feb","March","April","May","June","July","August","Sept","Oct","Nov","Dec"]
for (let i = 0; i < months.length; i++ ) {
  items.push(<MenuItem value={i} key={i} primaryText={months[i]} />);
}
class SelectMonth extends React.Component{
constructor(){
super();
this.state=({value:''})
var date = new Date();
var month = date.getMonth();
this.state=({value:month})

}
handleChange (event, nvalue)  {
console.log("let me check "+nvalue);
this.setState({value:nvalue});
console.log("inside select month"+this.state.value);

}

componentWillMount(){
if((this.props.MonthAdmin==="Admin")||(this.props.Admin==="Yes")){this.setState({value:"all"})}
}

render(){

return(
	<div>
	<SelectField value={this.state.value}  onChange={this.handleChange.bind(this)}  maxHeight={200} >
        	{items}
	 </SelectField>
	<Users monthreq={this.state.value}/>
	<Link to ="/addresort" style={styles.add_res}><AddNew/></Link>
	
	</div>
)
}
}
export default SelectMonth;


var styles={
	add_res:{
	position:"fixed",
	bottom:"0",
	right:"0"
	}
}