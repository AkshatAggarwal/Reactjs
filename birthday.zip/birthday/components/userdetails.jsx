import React from 'react';
import TextField from 'material-ui/TextField';
import DatePicker from 'material-ui/DatePicker';
import RaisedButton from 'material-ui/RaisedButton';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {Link} from 'react-router';
import fetch from 'node-fetch';

"use strict";
const image=[];
class InputDetails extends React.Component{
constructor(){
super();
this.state=({empid: '' , name:'',contact:'',dob:'',flag:'',prjEnddate:''})
}

handle_empid(e){this.setState({empid: e.target.value})}
handle_name(e){this.setState({name:e.target.value})}
handle_contact(e){this.setState({contact:e.target.value})}
handle_dob(x,date){this.setState({dob:JSON.stringify(date)})}
handle_prj_end_date(x,date){this.setState({prjEnddate:JSON.stringify(date)})}
submit(){
var self=this;
alert(`contat:${this.state.contact} empid:${this.state.empid} date:${this.state.dob}`);
fetch('http://localhost:3000/team',
{
method:'POST',
headers:{
'Accept':'application/json',
'Content-Type':'application/json',
},
body:JSON.stringify({
EMPID:this.state.empid,
FIRST_NAME:this.state.name,
conatct:this.state.contact,
dob:this.state.dob,
})
})
	.then(function (data) {  
console.log("Sttus"+data.status);
	console.log(data);
	return data;
})

.then(function(response){
	if(response.status==200){self.Auth_User(response)}
	console.log(response);
	});
	




}
Auth_User(response)
{
this.context.router.push('/birthdays/1');


}
render(){

return(
	<div>

	
	<TextField hintText="Emp Id" floatingLabelText="Employee Id" onChange={this.handle_empid.bind(this)} />		{this.state.empid}<br/>
	<TextField hintText="Name" floatingLabelText="Name" onChange={this.handle_name.bind(this)} />
	{this.state.name}<br/>
	<TextField hintText="Conatact No" floatingLabelText="Contact No" onChange={this.handle_contact.bind(this)}/>
	{this.state.contact}<br/>
	{image}<br/>
	<DatePicker hintText="DOB" onChange={(x, date) => this.handle_dob(x,date)} />
	<DatePicker hintText="Project End Date" onChange={(x, date) => this.handle_prjt_end_date(x,date)} />
	<RaisedButton label="Submit" primary={true} type="submit" onClick={() =>this.submit()}/>
	</div>
)
}
}

InputDetails.contextTypes = {
	    router: React.PropTypes.object.isRequired
}

export default InputDetails;