import React from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import List from 'material-ui/List/List';
import Avatar from 'material-ui/Avatar';
import ListItem from 'material-ui/List/ListItem';


"use strict";
var responseJson;
// var months; 
var i=0;
var item=[];
const months=["Jan","Feb","March","April","May","June","July","August","Sept","Oct","Nov","Dec"];

class Users extends React.Component{
constructor(props){
super(props);
this.state={data:[]}
this.state={month:'0'}
this.state={initial:1}
}


componentWillReceiveProps(nextProps){
console.log("inpropssection"+nextProps.monthreq);
this.setState({month:nextProps.monthreq})
console.log(nextProps.monthreq);
this.GetData(nextProps.monthreq);
}


GetData(request){
console.log("inside users"+request);
let url='http://localhost:3000/teams/'+request;
fetch(url, {
	method: 'GET'
})
.then((res) => res.json() )
.then((response) =>{
console.log(response);
console.log("Response aaya gya upar");
this.setState({data:response})
this.setState({initial:2})
console.log("s"+this.state.data.length);
// debugger;
})

}
componentDidMount(){this.GetData(this.props.monthreq);}


render(){
console.log(this.props.monthreq);
return(
	<div>
	 <Data data={this.state.data} fload={this.state.initial}  />
	</div>
)
}
}

export default Users;

class Data extends React.Component{
constructor(){
super();
this.state={nxt:0}
}

componentWillReceiveProps(nextProps){
console.log("inside data"+nextProps.data.FIRST_NAME);
this.setState({Data:nextProps.data});
console.log(nextProps.data.EMPID);
this.setState({nxt:2})
}
render(){

var Data=this.props.data;
var fl=this.props.fload;
var items=Data==undefined?null:Data.map(user => <div style={styles.user}><AllData data={user} /></div>)



return(
	<ul style={styles.ul_user}>
	{items}
	</ul>
)
}
}

class AllData extends React.Component{
render(){
return(

	<div style={this.props.data.FOOD_PREFERENCE=="Veg"?styles.user_veg:this.props.data.FOOD_PREFERENCE=="Non-Veg"?styles.user_nonveg:styles.nouser}><ImageUser/><Name user={this.props.data}/><Dob user={this.props.data}/></div>
)
}
}

class ImageUser extends React.Component{
render(){
return(
	<div style={styles.userimage}>
	<img  style={styles.userimage} src="https://x1.xingassets.com/assets/frontend_minified/img/users/nobody_m.original.jpg" />
	</div>
)
}
}
class Name extends React.Component{
render(){
var Name=this.props.user.FIRST_NAME==null?this.props.user.message:this.props.user.FIRST_NAME
return(
	<div>
	{Name}
	</div>
)
}
}

class Dob extends React.Component{
render(){
var DOB=this.props.user.DOB==null?null:this.props.user.DOB
var date = new Date(DOB);
var dated=DOB==null?null:date.getDate();
var month=DOB==null?null:(date.getMonth());
return(
	<div>
	{dated}{months[month]}
	</div>
)
}
}

var styles={
	ul_user:{
	margin:"0",
	padding:"0"
	},
	user:{
	width:"20%",
	float:"left",
	marginRight:"1"
	},
	nouser:{
	border:"none"
	},
	user_veg:{
	border: "1px solid green"
	},
	user_nonveg:{
	border: "1px solid red"
	},
	userimage:{
	width:"100%",

	}
}


