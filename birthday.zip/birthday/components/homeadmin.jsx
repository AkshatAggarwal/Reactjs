import React from 'react'
import ReactDOM from 'react-dom';
import SelectMonth from './selectmonth.jsx';

class HomeAdmin extends React.Component{
constructor(){
super();
this.state=({admin:"Yes"})
}
render(){
return(
	<div>
	<SelectMonth MonthAdmin={"Admin"} Admin={this.state.admin} />
	</div>
)
}
}

export default HomeAdmin;