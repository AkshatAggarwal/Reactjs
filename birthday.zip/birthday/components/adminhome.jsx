import React from 'react';
import ReactDOM from 'react-dom';
import FlatButton from 'material-ui/FlatButton';
import {Link} from 'react-router';
import AddNew from './addnewicon.jsx';
class AdminHome extends React.Component{
constructor(props){
super(props);
this.state={resdataforApp:[]}
}
componentDidMount()
{
	fetch('http://localhost:3000/resortpending',
		{
			method:"GET",
			headers:{
				'Accept':'application/json',
				'Content-Type':'application/json',
				}
		}
	)
		.then(response=>{
			console.log("Sttus"+response.status);
			console.log(response.ok);
			return response.json();
			
		})
		.then(data=>{
			console.log(data);
			console.log("data")
			this.setState({resdataforApp:data})
		})
}
render(){
return(
	<div>
	 <Link to="/home/1"><FlatButton label="Home" /></Link>
	 <Link to="/restraurants/"><FlatButton label="Restaurants" /></Link>
	 <Link to="/birthdays/1"><FlatButton label="Upcoming Birthdays" /></Link>
	<AddNew/>
	<Link to="/approveresort">{this.state.resdataforApp.length}</Link>
	</div>
)
}
}

export default AdminHome;