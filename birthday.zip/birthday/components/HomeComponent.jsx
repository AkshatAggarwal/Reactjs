import React from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import TextField from 'material-ui/TextField';
import RaisedButton from 'material-ui/RaisedButton';
import DatePicker from 'material-ui/DatePicker';
import  'isomorphic-fetch';
import 'es6-promise';
import { RouterContext } from 'react-router'
"use strict";
var route=2;

var array;

class Home extends React.Component{
constructor(){
super();
this.state=({empid: '',dob:'',flag:1,err:''});
this.Auth_User=this.Auth_User.bind(this);
}

handle_empid(e){
this.setState({empid: e.target.value.trim()});
var regex=new RegExp("^[0-9]*$");
this.handle_err(regex.test(e.target.value.trim()))
}

handle_err(error){if(error){this.setState({err:""})}else{this.setState({err:'Enter Correct Emp Id'})}console.log("vsdvfs"+this.state.err);}


handle_dob(x,date){this.setState({dob:JSON.stringify(date)})}

submit(e){
//alert(` empid:${this.state.empid} date:${this.state.dob}`);
debugger;
if((this.state.err=="Enter Correct Emp Id")||(this.state.dob=='')){return}
var self=this;
e.preventDefault();
fetch('http://localhost:3000/login',
{

method:'POST',
headers:{
'Accept':'application/json',
'Content-Type':'application/json',

},
body:JSON.stringify({
EMPID:this.state.empid,
dob:this.state.dob
})
})
.then(function (data) {  
console.log("Sttus"+data.status);
	console.log(data.ok);
	return data.json();
})
.then(function(response){
	if(response){self.Auth_User(response)}
	console.log(response);
	});

	




}
Auth_User(response)
{
response.message=="Admin"?this.context.router.push('/admin/1'):response.message=="Registered"?this.context.router.push('/birthdays/1'):response.message=="UnRegistered"?this.context.router.push('/details/10'):this.context.router.push('/clever/')

}

render(){
return(
	<div>
	
	<TextField hintText="Emp Id" floatingLabelText="Employee Id" onKeyUp={this.handle_empid.bind(this)} />
	{this.state.err}<br/>
	<DatePicker hintText="DOB" onChange={(x, date) =>this.handle_dob(event,date)}/>
	<RaisedButton label="Submit" primary={true} type="submit" onClick={this.submit.bind(this)}/>
	</div>
)
}
}

Home.contextTypes = {
	    router: React.PropTypes.object.isRequired
}

export default Home;