import React from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AddNew from './AddNew.jsx';
import List from 'material-ui/List/List';
import Avatar from 'material-ui/Avatar';
import ListItem from 'material-ui/List/ListItem';


class User extends React.Component{
constructor(){
super();
this.state={data:[]}
this.state={message:"Restraurants Data"}
}
componentDidMount(){
let url='/' ;
fetch('http://localhost:3000/resortdetails',{
method:"POST",
headers:{
'Accept':'application/json',
'Content-Type':'application/json',
},
body:JSON.stringify({message:"this.state.data"})
})
.then((res) => res.json() )
.then((response) =>{this.setState({data:response})
console.log("restraurants data");
console.log(this.state.data);
})
}
render(){

return(
	<div>
	<AllData resortdata={this.state.data==''? null: this.state.data} />	
	</div>
)
}
}

export default User;

class AllData extends React.Component{

render(){
var rest_data;
rest_data=this.props.resortdata;
var data=rest_data==null?null:rest_data.ResName;
return(
	<div>
	{data}
	</div>
)
}
}

class ImageUser extends React.Component{
constructor(){
super();
}
render(){
return(
	<div>
	<Avatar src="this.props.imageuser" />
	</div>
)
}
}
class Name extends React.Component{
constructor(){
super();
}
render(){
return(
	<div>
	{this.props.name}
	</div>
)
}
}
class Dob extends React.Component{

render(){
return(
	<div>
	{this.props.dOB}
	</div>
)
}
}
class EmpId extends React.Component{
constructor(){
super();
}
render(){
return(
	<div>
	{this.props.empid}
	</div>
)
}
}

