import React from 'react';
import ReactDOM from 'react-dom';
import Users from './AdminUsers.jsx';

class GetBirthdays extends React.Component{
constructor(){
super();
}

render(){
return(
	<div>
	<Users month={this.props.month_req}/>
	
	</div>
)
}
}

export default GetBirthdays;