import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App.jsx';
import {Router,Route,hashHistory,IndexRoute} from 'react-router';
import Home from './components/HomeComponent.jsx';
import AddNew from './components/addnewicon.jsx';
import SelectMonth from './components/selectmonth.jsx';
import Users from './components/AdminUsers.jsx';
import InputDetails from './components/userdetails.jsx';
import GetBirthdays from './components/getbirthdays.jsx';
import AdminHome from './components/adminhome.jsx';
import AppResort from './components/approveresort.jsx';
import AddRestraurant from './components/addrestraurants.jsx';
import HomeAdmin from './components/homeadmin.jsx';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import injectTapEventPlugin from 'react-tap-event-plugin';
injectTapEventPlugin();

ReactDOM.render(
<Router history={hashHistory}>
	<Route path="/" component={App} >
	<IndexRoute component={Home}/>
	<Route path="/admin/1" component={AdminHome}/>
	<Route path="/home/1" component={HomeAdmin}/>
	<Route path="/home/1" component={HomeAdmin}/>
	<Route path="/birthdays/1" component={SelectMonth}/>
	<Route path="/details/10" component={InputDetails}/>
	<Route path="/addresort" component={AddRestraurant} />
	<Route path="/approveresort" component={AppResort}/>
	</Route>
</Router>, document.getElementById('app'));


